/**
 * we-sync · browser half
 * 玻璃面板主题覆盖 + 壁纸背景层 + wallpaper_share 会话视图标签页。
 * 与 node half 通过同源 HTTP 路由（/we-sync/state、/we-sync/preview、
 * /we-sync/random）通信，不依赖任何 RPC 基础设施。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
export interface WeSyncInfo {
    version: number;
    kind: string;
    wallpaper: null | {
        title: string;
        type: string;
    };
}
export interface WeSyncSettings {
    enabled: boolean;
    panelAlpha: number;
    blur: number;
    shadow: number;
}
/** 包内单例 store：apply 循环更新，面板组件订阅渲染。 */
export declare const store: {
    info: WeSyncInfo | null;
    settings: WeSyncSettings;
    listeners: Set<() => void>;
    actions: {
        applyTheme: () => void;
        applyBackground: () => void;
    };
    subscribe(fn: () => void): () => void;
    notify(): void;
};
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map