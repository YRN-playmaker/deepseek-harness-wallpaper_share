export declare function WallpaperSharePanel(): import("react").JSX.Element;
//# sourceMappingURL=WallpaperSharePanel.d.ts.map